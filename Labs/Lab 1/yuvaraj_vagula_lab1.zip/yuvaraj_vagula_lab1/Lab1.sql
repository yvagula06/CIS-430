USE master;
-- create a db named COMPANY_yVagula. do NOT use master db.
IF DB_ID('COMPANY_yVagula') IS NULL
CREATE DATABASE COMPANY_yVagula;
GO
--use created db
USE COMPANY_yVagula;
GO

--use created db
USE COMPANY_yVagula;
GO
-- drop table, removes EMPLOYEE table & data
IF OBJECT_ID('dbo.EMPLOYEE') IS NOT NULL
DROP TABLE dbo.EMPLOYEE
-- create table named EMPLOYEE with correct row names & sizes
CREATE TABLE EMPLOYEE(
FNAME VARCHAR(25) NOT NULL,
MINIT CHAR,
LNAME VARCHAR(25) NOT NULL,
SSN CHAR(9) NOT NULL,
BDATE DATE,
[ADDRESS] VARCHAR(50) NOT NULL,
SEX CHAR NOT NULL,
SALARY DECIMAL(18,2),
SUPERSSN CHAR(9),
DNO INT NOT NULL
);
GO

--use created db
USE COMPANY_yVagula;
GO
-- drop table, removes DEPARTMENT table & data
IF OBJECT_ID('dbo.DEPARTMENT') IS NOT NULL
DROP TABLE dbo.EMPLOYEE
-- create table named DEPARTMENT with correct row names & sizes
CREATE TABLE DEPARTMENT(
DNAME VARCHAR(25) NOT NULL,
DNUMBER CHAR,
MGRSSN CHAR(9) NOT NULL,
MGRSTARTDATE DATE,
);
GO

-- insert values inside EMPLOYEE table
INSERT INTO EMPLOYEE VALUES('John', 'B', 'Smith', '123456789', '9-Jan-1955', '731
Fondren, Houston, TX', 'M', 30000, '987654321', 5);
INSERT INTO EMPLOYEE VALUES('Franklin', 'T', 'Wong', '333445555', '08-Dec-1945', '638
Voss, Houston, TX', 'M', 40000, '888665555', 5);
INSERT INTO EMPLOYEE VALUES('Joyce', 'A', 'English', '453453453', '21-Jul-1962', '5631
Rice, Houston, TX', 'M', 30000, '333445555', 5);
INSERT INTO EMPLOYEE VALUES('Ramash', 'K', 'Narayan', '666884444', '15-Sep-1952', '975
Fire Oak, Humble, TX', 'M', 38000, '333445555', 5);
INSERT INTO EMPLOYEE VALUES('James', 'E', 'Borg', '888665555', '10-Nov-1927', '975 Fire
Oak, Humble, TX', 'M', 55000, NULL, 1);
INSERT INTO EMPLOYEE VALUES('Jennifer', 'S', 'Wallace', '987654321', '20-Jun-1931', '291
Berry, Bellaire, TX', 'F', 43000, '888665555', 4);
INSERT INTO EMPLOYEE VALUES('Ahmad', 'V', 'Jabbar', '987987987', '29-Mar-1959', '980
Dallas, Houston, TX', 'M', 25000, '987654321', 4);
INSERT INTO EMPLOYEE VALUES('Alicia', 'J', 'Zelaya', '999887777', '19-Jul-1958', '3321
Castle, SPring, TX', 'F', 25000, '987654321', 4);
GO

-- insert values inside DEPARTMENT table
INSERT INTO DEPARTMENT VALUES ('Headquarters','1','888665555','19-Jun-71');
INSERT INTO DEPARTMENT VALUES ('Administration','4','987654321','01-Jan-85');
INSERT INTO DEPARTMENT VALUES ('Reasearch','5','333445555','22-May-78');
INSERT INTO DEPARTMENT VALUES ('Automation','7','123456789','06-Oct-05');

-- to see all EMPLOYEE records inserted
SELECT * from EMPLOYEE
-- to see all DEPARTMENT records inserted 
SELECT * from DEPARTMENT